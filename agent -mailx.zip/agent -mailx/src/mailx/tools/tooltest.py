import os, sys
# Ensure local tools folder is in path for module import
sys.path.insert(0, os.path.dirname(__file__))
from calendar_tool import CalendarTool
calendar_tool = CalendarTool()

result = calendar_tool._run(
    summary="Test Event",
    start_time="2025-04-20T16:00:00+05:30",
    end_time="2025-04-20T17:00:00+05:30",
    creator_email="shubhang.chakrawarty@gmail.com"
)

print("Result:", result)
