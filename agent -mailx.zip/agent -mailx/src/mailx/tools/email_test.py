#!/usr/bin/env python
import imaplib
import email
import time
import os
import yaml
from email.header import decode_header

def load_config(config_file='../config/email_config.yaml'):
    """Load email configuration from YAML file"""
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        config_path = os.path.join(os.path.dirname(script_dir), 'config', 'email_config.yaml')
        print(f"Loading config from: {config_path}")
        
        with open(config_path, 'r') as file:
            return yaml.safe_load(file)
    except Exception as e:
        print(f"Error loading config: {e}")
        # Fallback configuration
        return {
            'email': {
                'imap_server': 'imap.gmail.com',
                'username': 'shriyashbeohar1@gmail.com',
                'password': 'hpwl jvwg rkku reju',
                'folder': 'INBOX'
            },
            'check_frequency_seconds': 10,  # Check more frequently for testing
            'timezone': 'Asia/Kolkata'
        }

def test_email_connection():
    """Test connecting to Gmail and monitoring for new emails"""
    config = load_config()
    print(f"\nAttempting to connect to {config['email']['imap_server']} as {config['email']['username']}")
    
    try:
        # Connect to the mailbox
        mail = imaplib.IMAP4_SSL(config['email']['imap_server'])
        mail.login(config['email']['username'], config['email']['password'])
        mail.select(config['email']['folder'])
        print("✓ Successfully connected to mailbox!")
        
        # Check what's in the mailbox
        status, messages = mail.search(None, 'ALL')
        message_count = len(messages[0].split())
        print(f"✓ Found {message_count} total emails in {config['email']['folder']}")
        
        # Look for unread messages
        status, unread = mail.search(None, 'UNSEEN')
        unread_count = len(unread[0].split()) if unread[0] else 0
        print(f"✓ Found {unread_count} unread emails")
        
        print("\n--- Starting New Email Monitor ---")
        print("Send yourself an email now to test. Press Ctrl+C to stop.")
        print(f"Checking every {config['check_frequency_seconds']} seconds...\n")
        
        last_email_id = None
        check_count = 0
        
        # Monitor for new emails
        while True:
            check_count += 1
            print(f"Check #{check_count} - Looking for new unread messages...")
            
            status, messages = mail.search(None, 'UNSEEN')
            
            if status != 'OK' or not messages[0]:
                print("No new unread messages found.")
            else:
                # Get the latest email ID
                latest_email_id = messages[0].split()[-1]
                
                # Skip if we've already processed this email
                if last_email_id == latest_email_id:
                    print("No new unread messages since last check.")
                else:
                    print(f"New unread email found! ID: {latest_email_id}")
                    
                    # Update the last email ID
                    last_email_id = latest_email_id
                    
                    # Fetch the email
                    status, data = mail.fetch(latest_email_id, '(RFC822)')
                    
                    if status != 'OK':
                        print("Error fetching email content.")
                    else:
                        # Parse the email
                        raw_email = data[0][1]
                        email_message = email.message_from_bytes(raw_email)
                        
                        # Extract subject
                        subject = decode_header(email_message['Subject'])[0][0]
                        if isinstance(subject, bytes):
                            subject = subject.decode()
                        
                        # Extract sender
                        from_ = decode_header(email_message.get('From', ''))[0][0]
                        if isinstance(from_, bytes):
                            from_ = from_.decode()
                        
                        print(f"\n==== NEW EMAIL DETECTED ====")
                        print(f"From: {from_}")
                        print(f"Subject: {subject}")
                        print(f"==========================\n")
            
            print(f"Waiting {config['check_frequency_seconds']} seconds before next check...")
            time.sleep(config['check_frequency_seconds'])
            
    except KeyboardInterrupt:
        print("\nTest stopped by user.")
    except Exception as e:
        print(f"\nError: {str(e)}")
    finally:
        try:
            mail.close()
            mail.logout()
            print("Mail connection closed.")
        except:
            pass

if __name__ == "__main__":
    print("=== Gmail IMAP Connection Test ===\n")
    test_email_connection()
