#!/usr/bin/env python
import imaplib
import email
import time
import os
from datetime import datetime
from email.header import decode_header
import yaml
from mailx.crew import Mailx

# Email configuration
class EmailListener:
    def __init__(self, config_file='config/email_config.yaml'):
        self.config = self._load_config(config_file)
        self.last_email_id = None
        self.check_frequency = self.config.get('check_frequency_seconds', 60)
    
    def _load_config(self, config_file):
        config_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), config_file)
        try:
            with open(config_path, 'r') as file:
                return yaml.safe_load(file)
        except Exception as e:
            print(f"Error loading config: {e}")
            return {
                'email': {
                    'imap_server': 'imap.gmail.com',
                    'username': 'shriyashbeohar1@gmail.com',
                    'password': 'hpwl jvwg rkku reju ', 
                    'folder': 'INBOX'
                },
                'check_frequency_seconds': 60,
                'timezone': 'Asia/Kolkata'
            }
    
    def _connect_to_mailbox(self):
        """Connect to the IMAP server and select the mailbox"""
        mail = imaplib.IMAP4_SSL(self.config['email']['imap_server'])
        mail.login(self.config['email']['username'], self.config['email']['password'])
        mail.select(self.config['email']['folder'])
        return mail
    
    def _fetch_latest_email(self, mail):
        status, messages = mail.search(None, 'UNSEEN')
        
        if status != 'OK' or not messages[0]:
            return None
        
        latest_email_id = messages[0].split()[-1]

        if self.last_email_id == latest_email_id:
            return None
        

        self.last_email_id = latest_email_id
        
        # Fetch the email
        status, data = mail.fetch(latest_email_id, '(RFC822)')
        
        if status != 'OK':
            return None
        
        raw_email = data[0][1]
        email_message = email.message_from_bytes(raw_email)
        
        return self._parse_email(email_message)
    
    def _parse_email(self, email_message):

        subject = decode_header(email_message['Subject'])[0][0]
        if isinstance(subject, bytes):
            subject = subject.decode()
        
        # Extract sender
        from_ = decode_header(email_message.get('From', ''))[0][0]
        if isinstance(from_, bytes):
            from_ = from_.decode()
        
        # Extract body
        body = ""
        if email_message.is_multipart():
            for part in email_message.walk():
                if part.get_content_type() == "text/plain":
                    body = part.get_payload(decode=True).decode()
                    break
        else:
            body = email_message.get_payload(decode=True).decode()
        
        # Combine subject and body
        email_content = f"Subject: {subject}\n\n{body}"
        
        return {
            'sender': from_,
            'subject': subject,
            'body': body,
            'content': email_content,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
    
    def start_listening(self):
        """Start listening for new emails"""
        print(f"Email listener started. Checking every {self.check_frequency} seconds...")
        
        while True:
            try:
                mail = self._connect_to_mailbox()
                email_data = self._fetch_latest_email(mail)
                mail.close()
                mail.logout()
                
                if email_data:
                    print(f"New email received: {email_data['subject']}")
                    self._process_email(email_data)
                
                time.sleep(self.check_frequency)
                
            except Exception as e:
                print(f"Error in email listener: {e}")
                time.sleep(self.check_frequency)
    
    def _process_email(self, email_data):
        """Process a new email and trigger the orchestration workflow"""
        try:
            # Prepare inputs for the crew
            inputs = {
                'email_content': email_data['content'],
                'user_email': self.config['email']['username'],
                'timestamp': email_data['timestamp'],
                'timezone': self.config.get('timezone', 'UTC'),
                'sender': email_data['sender']
            }
            
            # Trigger the crew
            print("Starting email processing workflow...")
            Mailx().crew().kickoff(inputs=inputs)
            print("Email processing complete.")
            
        except Exception as e:
            print(f"Error triggering workflow: {e}")

def main():
    listener = EmailListener()
    listener.start_listening()

if __name__ == "__main__":
    main()
