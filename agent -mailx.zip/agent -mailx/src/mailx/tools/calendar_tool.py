from crewai.tools import BaseTool
from typing import Type, Optional
from pydantic import BaseModel, Field
from google.oauth2 import service_account
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
import datetime
import os
from google.oauth2.credentials import Credentials as UserCredentials
import yaml
from google.auth.transport.requests import Request

class CalendarToolInput(BaseModel):

    summary: str = Field(..., description="Title of the event")
    start_time: str = Field(..., description="Start time in RFC3339 format (e.g. 2025-04-19T15:00:00+05:30)")
    end_time: str = Field(..., description="End time in RFC3339 format (e.g. 2025-04-19T16:00:00+05:30)")
    description: str = Field(default="", description="Description of the event")
    attendees: list[str] = Field(default=[], description="List of attendee email addresses")
    location: str = Field(default="", description="Location of the event")
    calendar_id: Optional[str] = Field(default=None, description="Optional calendar ID to override the default one")
    creator_email: Optional[str] = Field(default=None, description="Email of the person creating this event (for identification only)")

class CalendarTool(BaseTool):
    name: str = "Google Calendar Tool"
    description: str = "Creates a Google Calendar event using a service account"
    args_schema: Type[BaseModel] = CalendarToolInput
    
    # Declare these as class variables to avoid Pydantic errors
    credentials_path: str = None
    default_calendar_id: str = None
    
    def __init__(self, calendar_id=None, credentials_path=None):
        super().__init__()
 
        current_dir = os.path.dirname(os.path.abspath(__file__))
        self.credentials_path = credentials_path or os.path.join(current_dir, 'dak-madad-450109-bcf82faac3f3.json')
        
        self.default_calendar_id = calendar_id or "shriyashbeohar1@gmail.com"  

    def _run(self, summary: str, start_time: str, end_time: str, description: str = "", 
             attendees: list = None, location: str = "", calendar_id: str = None, creator_email: str = None) -> str:
        if attendees is None:
            attendees = []
            
        target_calendar_id = calendar_id or self.default_calendar_id
        
        if creator_email and creator_email not in attendees:
            attendees.append(creator_email)
            

        full_description = description
        if creator_email:
            creator_note = f"\n\nCreated by: {creator_email}"
            full_description = f"{description}{creator_note}" if description else creator_note
            
        try:
   
            # Resolve paths
            base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            token_dir = os.path.join(base_dir, 'credentials')
            token_path = os.path.join(token_dir, 'gmail_token.yaml')
            scopes = ['https://www.googleapis.com/auth/calendar']
            credentials = None
            # Use existing OAuth token if it contains calendar scope
            if os.path.exists(token_path):
                info = yaml.safe_load(open(token_path))
                if 'https://www.googleapis.com/auth/calendar' in info.get('scopes', []):
                    credentials = UserCredentials.from_authorized_user_info(info, scopes)
                    # Refresh if expired
                    if credentials.expired and credentials.refresh_token:
                        credentials.refresh(Request())
            # If no valid OAuth creds, try interactive flow
            if not credentials:
                # Path to our Gmail API config (installed in mailx/config)
                config_path = os.path.join(base_dir, 'mailx', 'config', 'gmail_api_config.yaml')
                if os.path.exists(config_path):
                    with open(config_path) as f:
                        conf = yaml.safe_load(f)
                    secrets_path = conf['credentials']['client_secrets_path']
                    if not os.path.isabs(secrets_path):
                        secrets_path = os.path.join(base_dir, 'mailx', *secrets_path.replace('\\','/').split('/'))
                    flow = InstalledAppFlow.from_client_secrets_file(secrets_path, scopes)
                    credentials = flow.run_local_server(port=8080)
                    os.makedirs(token_dir, exist_ok=True)
                    with open(token_path, 'w') as token_file:
                        token_file.write(yaml.dump({
                            'token': credentials.token,
                            'refresh_token': credentials.refresh_token,
                            'token_uri': credentials.token_uri,
                            'client_id': credentials.client_id,
                            'client_secret': credentials.client_secret,
                            'scopes': credentials.scopes
                        }))
                else:
                    # Fallback to service account impersonation
                    impersonate = creator_email or self.default_calendar_id
                    credentials = service_account.Credentials.from_service_account_file(
                        self.credentials_path,
                        scopes=scopes,
                        subject=impersonate
                    )

            service = build("calendar", "v3", credentials=credentials)

 
            event = {
                "summary": summary,
                "location": location,
                "description": full_description,
                "start": {"dateTime": start_time, "timeZone": "Asia/Kolkata"},
                "end": {"dateTime": end_time, "timeZone": "Asia/Kolkata"},
                "attendees": [{"email": email} for email in attendees] if attendees else [],
                # Make the event public and accessible via link
                "visibility": "public",
                # Allow anyone with the link to view the event
                "transparency": "transparent",
                # Add default reminders
                "reminders": {
                    "useDefault": False,
                    "overrides": [
                        {"method": "email", "minutes": 24 * 60},
                        {"method": "popup", "minutes": 30}
                    ]
                }
            }

            # Insert the event and get response
            created_event = service.events().insert(
                calendarId=target_calendar_id, 
                body=event, 
                sendUpdates="all",
                conferenceDataVersion=1 
            ).execute()
            
            print(f"Event Created in calendar {target_calendar_id}:", created_event)
            
            # Extract and format the event ID to create a direct accessible link
            event_id = created_event.get('id')
            
            # Generate a direct calendar link that's more universally accessible
            calendar_link = created_event.get('htmlLink')
            
            # Also provide a direct access link using the calendar ID and event ID
            direct_link = f"https://calendar.google.com/calendar/event?eid={event_id}&ctz=Asia/Kolkata"
            
            # Build response with creator info if available
            creator_info = f"\nCreator: {creator_email}" if creator_email else ""
            
            return f"Event created successfully!{creator_info}\n\nOfficial Calendar Link: {calendar_link}\n\nAlternative Access Link: {direct_link}\n\nEvent ID: {event_id}\n\nCreated in Calendar: {target_calendar_id}"
        
        except Exception as e:
            return f"Failed to create event: {str(e)}"

    @staticmethod
    def get_instance(calendar_id=None, credentials_path=None):
        """Factory method to create a preconfigured instance of CalendarTool.
        
        This method allows users to easily create a CalendarTool with their own settings.
        
        Args:
            calendar_id (str, optional): Calendar ID to use for events.
            credentials_path (str, optional): Path to service account JSON file.
            
        Returns:
            CalendarTool: Configured instance ready to use.
        """
        return CalendarTool(calendar_id=calendar_id, credentials_path=credentials_path)