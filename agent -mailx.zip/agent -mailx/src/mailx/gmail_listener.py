#!/usr/bin/env python
import os
import base64
import yaml
import time
from datetime import datetime
from email.mime.text import MIMEText
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from mailx.crew import Mailx
import re

# Gmail API scopes needed for reading emails, modifying labels, and sending replies
SCOPES = [
    'https://www.googleapis.com/auth/gmail.readonly',
    'https://www.googleapis.com/auth/gmail.modify',
    'https://www.googleapis.com/auth/gmail.labels',
    'https://www.googleapis.com/auth/gmail.send',
    'https://www.googleapis.com/auth/calendar'
]

class GmailListener:
    """Listens for new emails using Gmail API and triggers workflow when new emails arrive"""
    
    def __init__(self, config_file=r'G:\dem\turtle voice\mailx\src\mailx\config\gmail_api_config.yaml'):
        """Initialize the Gmail API listener"""
        self.config = self._load_config(config_file)
        self.service = None
        self.seen_message_ids = set()
        self.check_frequency = self.config['email'].get('check_frequency_seconds', 60)
        self.max_results = self.config['email'].get('max_results', 10)
        self.search_query = self.config['email'].get('search_query', 'is:unread')
        self.user_id = self.config['email'].get('user_id', 'me')
        
        # Ensure credentials directory exists
        os.makedirs(os.path.dirname(self.config['credentials']['token_path']), exist_ok=True)
    
    def _load_config(self, config_file):
        """Load Gmail API configuration from YAML file"""
        try:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            
            # Use the config_file parameter properly
            if os.path.isabs(config_file):
                config_path = config_file
            else:
                # If it's a relative path, resolve it relative to the base directory
                config_path = os.path.join(base_dir, *config_file.split('/'))
                
            print(f"Loading config from: {config_path}")
            
            with open(config_path, 'r') as file:
                return yaml.safe_load(file)
        except Exception as e:
            print(f"Error loading config: {e}")
            # Default configuration
            return {
                'credentials': {
                    'client_secrets_path': 'credentials/client_secret.json',
                    'token_path': 'credentials/gmail_token.yaml'
                },
                'email': {
                    'check_frequency_seconds': 60,
                    'user_id': 'me',
                    'search_query': 'is:unread',
                    'max_results': 10
                },
                'timezone': 'Asia/Kolkata'
            }
    
    def _get_gmail_service(self):
        """Connect to Gmail API and return service object"""
        creds = None
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # Project root directory
        
        # Get paths from config and make them absolute if they're not already
        token_path = self.config['credentials']['token_path']
        if not os.path.isabs(token_path):
            token_path = os.path.join(base_dir, *token_path.split('/'))
        
        credentials_path = self.config['credentials']['client_secrets_path']
        if not os.path.isabs(credentials_path):
            credentials_path = os.path.join(base_dir, *credentials_path.split('/'))
            
        print(f"Using token path: {token_path}")
        print(f"Using credentials path: {credentials_path}")
        
        # Make sure token directory exists
        os.makedirs(os.path.dirname(token_path), exist_ok=True)
        
        # Check if we have valid token
        if os.path.exists(token_path):
            try:
                creds = Credentials.from_authorized_user_info(
                    yaml.safe_load(open(token_path)))
            except Exception as e:
                print(f"Error loading credentials: {e}")
        
        # If credentials don't exist or are invalid, do the OAuth flow
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                try:
                    creds.refresh(Request())
                except Exception as e:
                    print(f"Error refreshing credentials: {e}")
                    creds = None
            
            if not creds:
                try:
                    flow = InstalledAppFlow.from_client_secrets_file(
                        credentials_path, SCOPES)
                    # Use port 8080 specifically instead of a random port
                    # This should match an authorized redirect URI in Google Cloud Console
                    creds = flow.run_local_server(port=8080)
                
                    # Save the credentials for future use
                    with open(token_path, 'w') as token:
                        token.write(yaml.dump({
                            'token': creds.token,
                            'refresh_token': creds.refresh_token,
                            'token_uri': creds.token_uri,
                            'client_id': creds.client_id,
                            'client_secret': creds.client_secret,
                            'scopes': creds.scopes
                        }))
                    print(f"Credentials saved to {token_path}")
                except Exception as e:
                    print(f"Error in authorization flow: {e}")
                    return None
        
        # Create the Gmail API service
        try:
            service = build('gmail', 'v1', credentials=creds)
            return service
        except Exception as e:
            print(f"Error building Gmail service: {e}")
            return None
    
    def _list_messages(self, query=None):
        """List messages matching the specified query"""
        if not query:
            query = self.search_query
            
        try:
            response = self.service.users().messages().list(
                userId=self.user_id, q=query, maxResults=self.max_results).execute()
            messages = response.get('messages', [])
            return messages
        except Exception as e:
            print(f"Error listing messages: {e}")
            return []
    
    def _get_message(self, msg_id):
        """Get a specific message by ID"""
        try:
            message = self.service.users().messages().get(
                userId=self.user_id, id=msg_id, format='full').execute()
            return message
        except Exception as e:
            print(f"Error getting message: {e}")
            return None
    
    def _parse_message(self, message):
        """Parse a Gmail message into a structured format"""
        if not message:
            return None
        
        # Extract headers
        headers = {}
        for header in message['payload']['headers']:
            headers[header['name'].lower()] = header['value']
        
        # Extract parts and body
        def get_body(payload):
            if 'parts' in payload:
                for part in payload['parts']:
                    if part['mimeType'] == 'text/plain':
                        if 'data' in part['body']:
                            return base64.urlsafe_b64decode(part['body']['data']).decode('utf-8')
                    elif 'parts' in part:
                        body = get_body(part)
                        if body:
                            return body
            elif payload['mimeType'] == 'text/plain':
                if 'data' in payload['body']:
                    return base64.urlsafe_b64decode(payload['body']['data']).decode('utf-8')
            return None
        
        orig_body = get_body(message['payload'])
        # sanitize and trim to reduce tokens
        clean_body = re.sub(r'[^ -]+', ' ', orig_body or '')
        clean_body = clean_body.strip()[:2000]
        body = clean_body
        
        # Create structured message
        return {
            'id': message['id'],
            'thread_id': message['threadId'],
            'label_ids': message.get('labelIds', []),
            'subject': headers.get('subject', '(No Subject)'),
            'from': headers.get('from', ''),
            'to': headers.get('to', ''),
            'date': headers.get('date', ''),
            'body': body,
            'snippet': body,
            'content': f"Subject: {headers.get('subject', '(No Subject)')}\n\n{body}"
        }
    
    def _mark_as_read(self, msg_id):
        """Mark a message as read by removing the UNREAD label"""
        try:
            self.service.users().messages().modify(
                userId=self.user_id,
                id=msg_id,
                body={'removeLabelIds': ['UNREAD']}
            ).execute()
            return True
        except Exception as e:
            print(f"Error marking message as read: {e}")
            return False
    
    def _apply_label(self, msg_id, label_name):
        """Apply a label to a message, creating the label if it doesn't exist"""
        try:
            # Check if label exists
            labels = self.service.users().labels().list(userId=self.user_id).execute().get('labels', [])
            label_id = None
            
            for label in labels:
                if label['name'] == label_name:
                    label_id = label['id']
                    break
            
            # Create label if it doesn't exist
            if not label_id:
                created_label = self.service.users().labels().create(
                    userId=self.user_id,
                    body={'name': label_name}
                ).execute()
                label_id = created_label['id']
            
            # Apply label to message
            self.service.users().messages().modify(
                userId=self.user_id,
                id=msg_id,
                body={'addLabelIds': [label_id]}
            ).execute()
            
            return True
        except Exception as e:
            print(f"Error applying label: {e}")
            return False
    
    def _process_email(self, email_data):
        """Process a new email and trigger the orchestration workflow"""
        try:
            # Prepare inputs for the crew
            inputs = {
                'email_content': email_data['content'],
                'user_email': email_data.get('to', self.user_id),
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'timezone': self.config.get('timezone', 'UTC'),  # Access timezone directly from root config
                'sender': email_data['from'],
                'message_id': email_data['id'],
                'thread_id': email_data['thread_id']
            }
            
            # Trigger the crew
            print("Starting email processing workflow...")
            
            # Initialize the Mailx class & trigger the crew workflow (kickoff/run fallback)
            mailx = Mailx()
            crew_instance = mailx.crew()
            try:
                result = crew_instance.kickoff(inputs=inputs)
            except AttributeError:
                result = crew_instance.run(inputs=inputs)
            
            print("Email processing complete.")
            
            # Extract and display summary from summary_task
            summary_entry = None
            if isinstance(result, dict):
                summary_entry = result.get("summary_task")
            elif hasattr(result, "summary_task"):
                summary_entry = getattr(result, "summary_task")
            # If summary task returned a dict, get its 'output' or 'result'
            if isinstance(summary_entry, dict):
                summary_text = summary_entry.get("output") or summary_entry.get("result")
            else:
                summary_text = summary_entry
            if summary_text:
                print("\n==== SUMMARY ====")
                print(summary_text)
            
            # Return True if we got any result (success)
            return True if result is not None else False
            
        except Exception as e:
            print(f"Error triggering workflow: {e}")
            return None
    
    def _send_reply(self, thread_id, to, subject, body):
        """Send a reply to an email thread"""
        try:
            message = MIMEText(body)
            message['to'] = to
            message['subject'] = f"Re: {subject}"
            raw_message = base64.urlsafe_b64encode(message.as_string().encode('utf-8')).decode('utf-8')
            
            self.service.users().messages().send(
                userId=self.user_id,
                body={
                    'raw': raw_message,
                    'threadId': thread_id
                }
            ).execute()
            
            return True
        except Exception as e:
            print(f"Error sending reply: {e}")
            return False
    
    def start_listening(self):
        """Start listening for new emails"""
        print(f"Gmail API listener started. Checking every {self.check_frequency} seconds...")
        
        # Connect to Gmail API
        self.service = self._get_gmail_service()
        if not self.service:
            print("Failed to connect to Gmail API. Please check your configuration.")
            return
        
        # Get initial set of messages to avoid processing existing unread emails
        initial_messages = self._list_messages()
        for msg in initial_messages:
            self.seen_message_ids.add(msg['id'])
        
        print(f"Found {len(initial_messages)} existing unread messages. Will only process new messages from now on.")
        
        # Main monitoring loop
        while True:
            try:
                # Get unread messages
                messages = self._list_messages()
                
                # Check for new messages
                new_messages = [msg for msg in messages if msg['id'] not in self.seen_message_ids]
                
                if new_messages:
                    print(f"Found {len(new_messages)} new unread messages.")
                    
                    # Process new messages
                    for msg in new_messages:
                        self.seen_message_ids.add(msg['id'])
                        
                        # Get full message
                        full_msg = self._get_message(msg['id'])
                        if full_msg:
                            parsed_msg = self._parse_message(full_msg)
                            
                            if parsed_msg:
                                print(f"\n==== NEW EMAIL DETECTED ====")
                                print(f"From: {parsed_msg['from']}")
                                print(f"Subject: {parsed_msg['subject']}")
                                print(f"==========================\n")
                                
                                # Process the email
                                result = self._process_email(parsed_msg)
                                if result:
                                    print(f"Email processing completed successfully")
                                    # Mark as processed in Gmail
                                    self._apply_label(msg['id'], 'Processed')
                                else:
                                    print(f"Email processing failed or returned no result")
                                    # Apply a different label to indicate failure
                                    self._apply_label(msg['id'], 'ProcessingFailed')
                                
                                # Mark as read
                                self._mark_as_read(msg['id'])
                
                # Wait before next check
                time.sleep(self.check_frequency)
                
            except Exception as e:
                print(f"Error in monitoring loop: {e}")
                time.sleep(self.check_frequency)

def main():
    listener = GmailListener()
    listener.start_listening()

if __name__ == "__main__":
    main()
