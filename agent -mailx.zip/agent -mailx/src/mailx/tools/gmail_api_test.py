#!/usr/bin/env python
import os
import base64
import yaml
import time
from email.mime.text import MIMEText
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build


SCOPES = ['https://www.googleapis.com/auth/gmail.readonly',
          'https://www.googleapis.com/auth/gmail.modify',
          'https://www.googleapis.com/auth/gmail.labels']

def load_config(config_file= r'G:\dem\turtle voice\mailx\src\mailx\config\gmail_api_config.yaml'):
    """Load Gmail API configuration from YAML file"""
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Actually use the config_file parameter
        if os.path.isabs(config_file):
            config_path = config_file
        else:
            # If it's a relative path, resolve it relative to the script directory
            config_path = os.path.join(os.path.dirname(script_dir), *config_file.split('/'))
            
        print(f"Loading config from: {config_path}")
        
        with open(config_path, 'r') as file:
            return yaml.safe_load(file)
    except Exception as e:
        print(f"Error loading config: {e}")
        return None

def get_gmail_service():
    """Connect to Gmail API and return service object"""
    config = load_config()
    if not config:
        print("Could not load configuration. Please ensure gmail_api_config.yaml exists.")
        return None
    
    creds = None
    script_dir = os.path.dirname(os.path.abspath(__file__))
    base_dir = os.path.dirname(os.path.dirname(script_dir))  # Root project directory
    
    # Get paths from config and make them absolute if they're not already
    token_path = config['credentials']['token_path']
    if not os.path.isabs(token_path):
        token_path = os.path.join(base_dir, *token_path.split('/'))
    
    credentials_path = config['credentials']['client_secrets_path']
    if not os.path.isabs(credentials_path):
        credentials_path = os.path.join(base_dir, *credentials_path.split('/'))
    
    print(f"Using token path: {token_path}")
    print(f"Using credentials path: {credentials_path}")
    
    # Make sure token directory exists
    os.makedirs(os.path.dirname(token_path), exist_ok=True)
    
    # Check if we have valid token
    if os.path.exists(token_path):
        try:
            creds = Credentials.from_authorized_user_info(
                yaml.safe_load(open(token_path)))
        except Exception as e:
            print(f"Error loading credentials: {e}")
    
    # If credentials don't exist or are invalid, do the OAuth flow
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            try:
                creds.refresh(Request())
            except Exception as e:
                print(f"Error refreshing credentials: {e}")
                creds = None
        
        if not creds:
            try:
                flow = InstalledAppFlow.from_client_secrets_file(
                    credentials_path, SCOPES)
                # Use port 8080 specifically instead of a random port
                # This should match an authorized redirect URI in Google Cloud Console
                creds = flow.run_local_server(port=8080)
            
                # Save the credentials for future use
                with open(token_path, 'w') as token:
                    token.write(yaml.dump({
                        'token': creds.token,
                        'refresh_token': creds.refresh_token,
                        'token_uri': creds.token_uri,
                        'client_id': creds.client_id,
                        'client_secret': creds.client_secret,
                        'scopes': creds.scopes
                    }))
                print(f"Credentials saved to {token_path}")
            except Exception as e:
                print(f"Error in authorization flow: {e}")
                return None
    
    # Create the Gmail API service
    try:
        service = build('gmail', 'v1', credentials=creds)
        return service
    except Exception as e:
        print(f"Error building Gmail service: {e}")
        return None

def get_profile_info(service):
    """Get user profile information"""
    try:
        profile = service.users().getProfile(userId='me').execute()
        return profile
    except Exception as e:
        print(f"Error getting profile: {e}")
        return None

def list_labels(service):
    """List all Gmail labels"""
    try:
        results = service.users().labels().list(userId='me').execute()
        labels = results.get('labels', [])
        return labels
    except Exception as e:
        print(f"Error listing labels: {e}")
        return []

def list_messages(service, query='is:unread', max_results=10):
    """List messages matching the specified query"""
    try:
        response = service.users().messages().list(
            userId='me', q=query, maxResults=max_results).execute()
        messages = response.get('messages', [])
        return messages
    except Exception as e:
        print(f"Error listing messages: {e}")
        return []

def get_message(service, msg_id):
    """Get a specific message by ID"""
    try:
        message = service.users().messages().get(
            userId='me', id=msg_id, format='full').execute()
        return message
    except Exception as e:
        print(f"Error getting message: {e}")
        return None

def parse_message(message):
    """Parse a Gmail message into a structured format"""
    if not message:
        return None
    
    # Extract headers
    headers = {}
    for header in message['payload']['headers']:
        headers[header['name'].lower()] = header['value']
    
    # Extract parts and body
    def get_body(payload):
        if 'parts' in payload:
            for part in payload['parts']:
                if part['mimeType'] == 'text/plain':
                    if 'data' in part['body']:
                        return base64.urlsafe_b64decode(part['body']['data']).decode('utf-8')
                elif 'parts' in part:
                    body = get_body(part)
                    if body:
                        return body
        elif payload['mimeType'] == 'text/plain':
            if 'data' in payload['body']:
                return base64.urlsafe_b64decode(payload['body']['data']).decode('utf-8')
        return None
    
    body = get_body(message['payload'])
    
    # Create structured message
    return {
        'id': message['id'],
        'thread_id': message['threadId'],
        'label_ids': message.get('labelIds', []),
        'subject': headers.get('subject', '(No Subject)'),
        'from': headers.get('from', ''),
        'to': headers.get('to', ''),
        'date': headers.get('date', ''),
        'body': body or '',
        'snippet': message.get('snippet', ''),
        'content': f"Subject: {headers.get('subject', '(No Subject)')}\n\n{body or message.get('snippet', '')}"
    }

def monitor_inbox():
    """Monitor inbox for new messages"""
    print("=== Gmail API Connection Test ===\n")
    
    # Connect to Gmail API
    service = get_gmail_service()
    if not service:
        print("Failed to connect to Gmail API. Please check your configuration.")
        return
    
    # Get user profile
    profile = get_profile_info(service)
    if profile:
        print(f"\nu2713 Successfully connected to Gmail API!")
        print(f"u2713 Email address: {profile['emailAddress']}")
        print(f"u2713 Messages total: {profile['messagesTotal']}")
        print(f"u2713 Threads total: {profile['threadsTotal']}")
    
    # Get labels
    labels = list_labels(service)
    if labels:
        print(f"u2713 Found {len(labels)} labels")
        inbox_label = next((label for label in labels if label['name'] == 'INBOX'), None)
        if inbox_label:
            print(f"u2713 INBOX label ID: {inbox_label['id']}")
    
    # Start monitoring for new messages
    print("\n--- Starting New Email Monitor ---")
    print("Send yourself an email now to test. Press Ctrl+C to stop.")
    print("Checking every 10 seconds...\n")
    
    seen_message_ids = set()
    check_count = 0
    
    try:
        while True:
            check_count += 1
            print(f"Check #{check_count} - Looking for new unread messages...")
            
            # Get unread messages
            messages = list_messages(service, query='is:unread')
            
            if not messages:
                print("No unread messages found.")
            else:
                print(f"Found {len(messages)} unread messages.")
                
                # Check for new messages
                new_messages = [msg for msg in messages if msg['id'] not in seen_message_ids]
                
                if not new_messages:
                    print("No new unread messages since last check.")
                else:
                    print(f"Found {len(new_messages)} new unread messages!")
                    
                    # Process new messages
                    for msg in new_messages:
                        seen_message_ids.add(msg['id'])
                        
                        # Get full message
                        full_msg = get_message(service, msg['id'])
                        if full_msg:
                            parsed_msg = parse_message(full_msg)
                            
                            if parsed_msg:
                                print(f"\n==== NEW EMAIL DETECTED ====")
                                print(f"From: {parsed_msg['from']}")
                                print(f"Subject: {parsed_msg['subject']}")
                                print(f"Snippet: {parsed_msg['snippet']}")
                                print(f"==========================\n")
            
            print(f"Waiting 10 seconds before next check...")
            time.sleep(10)
    
    except KeyboardInterrupt:
        print("\nTest stopped by user.")
    except Exception as e:
        print(f"\nError: {str(e)}")

if __name__ == "__main__":
    monitor_inbox()
