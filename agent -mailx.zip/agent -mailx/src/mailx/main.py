#!/usr/bin/env python
import sys
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.stderr.reconfigure(encoding='utf-8', errors='replace')
import warnings
import re

from datetime import datetime

from mailx.crew import Mailx
from mailx.gmail_listener import GmailListener

warnings.filterwarnings("ignore", category=SyntaxWarning, module="pysbd")

# This main file is intended to be a way for you to run your
# crew locally, so refrain from adding unnecessary logic into this file.

def listen():
    """
    Start the Gmail API listener to monitor inbox and process emails automatically.
    """
    print("Starting Gmail API listener...")
    try:
        listener = GmailListener()
        listener.start_listening()
    except Exception as e:
        raise Exception(f"An error occurred in the Gmail listener: {e}")

def run():
    """
    Run the crew with a sample email.
    """
    # Sample email content for testing
    email_content = """
    Subject: Team Meeting Next Week
    
    Hi Team,
    
    Let's schedule a team meeting for next Tuesday, April 23rd, from 2:00 PM to 3:30 PM.
    We'll discuss the quarterly results and plan for the upcoming product launch.
    
    Please make sure to prepare your section updates before the meeting.
    
    Thanks,
    John
    """
    
    # sanitize and truncate to reduce tokens
    email_content = re.sub(r'[^ -~]+', ' ', email_content)
    email_content = email_content.strip()[:2000]
    
    inputs = {
        'email_content': email_content,
        'user_email': 'shriyashbeohar1@gmail.com',
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'timezone': 'Asia/Kolkata',
        'sender': 'john@example.com',
        'message_id': 'sample_msg_123',
        'thread_id': 'sample_thread_123'
    }
    
    try:
        import io, contextlib
        crew = Mailx().crew()
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
            results = crew.kickoff(inputs=inputs)
        # signal successful completion with final output
        print(f"Assistant: Workflow is complete. Here is your result:\n{results}\n\nIs there anything else I can help you with?")
    except Exception as e:
        raise Exception(f"An error occurred while running the crew: {e}")


def train():
    """
    Train the crew for a given number of iterations.
    """
    # Sample email content for training
    email_content = """
    Subject: Calendar Entry for Product Demo
    
    Please add a calendar entry for our product demo with Client XYZ.
    Date: April 25, 2025
    Time: 10:00 AM - 11:30 AM
    
    Thanks!
    """
    
    inputs = {
        'email_content': email_content,
        'user_email': 'shriyashbeohar1@gmail.com',
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'timezone': 'Asia/Kolkata',
        'sender': 'colleague@example.com',
        'message_id': 'train_msg_123',
        'thread_id': 'train_thread_123'
    }
    
    try:
        Mailx().crew().train(n_iterations=int(sys.argv[1]), filename=sys.argv[2], inputs=inputs)

    except Exception as e:
        raise Exception(f"An error occurred while training the crew: {e}")

def replay():
    """
    Replay the crew execution from a specific task.
    """
    try:
        Mailx().crew().replay(task_id=sys.argv[1])

    except Exception as e:
        raise Exception(f"An error occurred while replaying the crew: {e}")

def test():
    """
    Test the crew execution for a calendar event and return the results.
    """
    # Sample email for Calendar event testing
    email_content = """
    Subject: Calendar Entry for Product Demo

    Please add a calendar entry for our product demo with Client XYZ.
    Date: April 25, 2025
    Time: 10:00 AM - 11:30 AM

    Thanks!
    """
    # sanitize and truncate
    email_content = re.sub(r'[^ -~]+', ' ', email_content)
    email_content = email_content.strip()[:2000]

    inputs = {
        'email_content': email_content,
        'user_email': 'shriyashbeohar1@gmail.com',
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'timezone': 'Asia/Kolkata',
        'sender': 'colleague@example.com',
        'message_id': 'test_calendar_msg_123',
        'thread_id': 'test_calendar_thread_123'
    }

    try:
        # execute workflow and show logs
        crew = Mailx().crew()
        results = crew.kickoff(inputs=inputs)
        # Show outputs for all tasks
        print("Assistant: Workflow is complete. Here are the outputs for each task:")
        for task_name, output in results.dict().items():
            print(f"- {task_name}: {output}")
        print("\nIs there anything else I can help you with?")
    except Exception as e:
        raise Exception(f"An error occurred while testing the crew: {e}")

# Add command-line argument handling
if __name__ == "__main__":
    if len(sys.argv) > 1:
        if sys.argv[1] == "listen":
            listen()
        elif sys.argv[1] == "run":
            run()
        elif sys.argv[1] == "train" and len(sys.argv) >= 4:
            train()
        elif sys.argv[1] == "replay" and len(sys.argv) >= 3:
            replay()
        elif sys.argv[1] == "test":
            test()
        elif sys.argv[1] == "api-test":
            # Simple test for Gmail API
            print("Running Gmail API test...")
            from mailx.tools.gmail_api_test import monitor_inbox
            monitor_inbox()
        else:
            print("Invalid command or missing arguments.")
            print("Usage:")
            print("  python -m mailx.main listen    - Start Gmail API listener")
            print("  python -m mailx.main api-test  - Test Gmail API connection")
            print("  python -m mailx.main run       - Run with sample email")
            print("  python -m mailx.main train N FILE   - Train for N iterations and save to FILE")
            print("  python -m mailx.main replay TASK_ID - Replay execution from task")
            print("  python -m mailx.main test       - Test for calendar event")
    else:
        # Default to run if no arguments
        run()
