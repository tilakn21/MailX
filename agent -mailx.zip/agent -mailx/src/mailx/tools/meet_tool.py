from crewai.tools import BaseTool
from typing import Type
from pydantic import BaseModel, Field
from google.oauth2 import service_account
from googleapiclient.discovery import build
from uuid import uuid4

class MeetToolInput(BaseModel):
    """Input schema for MeetTool."""
    summary: str = Field(..., description="Meeting topic/title")
    start_time: str = Field(..., description="RFC3339 start time (e.g. 2025-04-19T15:00:00+05:30)")
    end_time: str = Field(..., description="RFC3339 end time (e.g. 2025-04-19T16:00:00+05:30)")
    attendees: list[str] = Field(default=[], description="List of emails to invite")

class MeetTool(BaseTool):
    name: str = "Google Meet Scheduler"
    description: str = "Schedules a Google Meet by creating a Calendar event with a Meet link"
    args_schema: Type[BaseModel] = MeetToolInput

    def _run(self, summary: str, start_time: str, end_time: str, attendees: list[str]) -> str:
        try:
            credentials = service_account.Credentials.from_service_account_file(
                'dak-madad-450109-bcf82faac3f3.json',
                scopes=['https://www.googleapis.com/auth/calendar']
            ).with_subject("shriyashbeohar1@gmail.com")  # Replace with actual email

            service = build("calendar", "v3", credentials=credentials)

            event = {
                "summary": summary,
                "start": {"dateTime": start_time, "timeZone": "Asia/Kolkata"},
                "end": {"dateTime": end_time, "timeZone": "Asia/Kolkata"},
                "attendees": [{"email": email} for email in attendees],
                "conferenceData": {
                    "createRequest": {
                        "requestId": str(uuid4()),
                        "conferenceSolutionKey": {"type": "hangoutsMeet"}
                    }
                }
            }

            created_event = service.events().insert(
                calendarId="primary",
                body=event,
                conferenceDataVersion=1
            ).execute()

            meet_link = created_event.get("hangoutLink", "❌ No Meet link generated.")
            return f" Google Meet scheduled: {meet_link}"
        
        except Exception as e:
            return f" Failed to schedule Meet: {str(e)}"
