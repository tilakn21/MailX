from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task, before_kickoff
from mailx.tools.calendar_tool import CalendarTool

# If you want to run a snippet of code before or after the crew starts,
# you can use the @before_kickoff and @after_kickoff decorators
# https://docs.crewai.com/concepts/crews#example-crew-class-with-decorators

@CrewBase
class Mailx():
    """Mailx crew"""
    agents_config = 'config/agents.yaml'
    tasks_config = 'config/tasks.yaml'

    @agent
    def email_router_agent(self) -> Agent:
        return Agent(
            config=self.agents_config['email_router_agent'],
            verbose=True,
            max_iter=5,
            max_rpm=30,
        )

    @agent
    def meeting_scheduler_agent(self) -> Agent:
        return Agent(
            config=self.agents_config['meeting_scheduler_agent'],
            verbose=False
        )

    @agent
    def calendar_manager_agent(self) -> Agent:
        return Agent(
            config=self.agents_config['calendar_manager_agent'],
            verbose=True,
            tools=[CalendarTool()]
        )

    @agent
    def summary_agent(self) -> Agent:
        return Agent(
            config=self.agents_config['summary_agent'],
            verbose=False
        )

    # To learn more about structured task outputs,
    # task dependencies, and task callbacks, check out the documentation:
    # https://docs.crewai.com/concepts/tasks#overview-of-a-task
    @task
    def email_router_task(self) -> Task:
        return Task(
            config=self.tasks_config['email_router_task'],
            agent=self.email_router_agent()
        )

    @task
    def calendar_scheduling_task(self) -> Task:
        return Task(
            config=self.tasks_config['calendar_scheduling_task'],
            agent=self.calendar_manager_agent(),
            context=[self.email_router_task()],
        )

    @task
    def google_meet_creation_task(self) -> Task:
        return Task(
            config=self.tasks_config['google_meet_creation_task'],
            agent=self.meeting_scheduler_agent(),
            context=[self.email_router_task()],
        )

    @task
    def summary_task(self) -> Task:
        # After summarizing actions for each processed email, send the summary back to the manager agent
        return Task(
            config=self.tasks_config['summary_task'],
            agent=self.summary_agent(),
            context=[
                self.email_router_task(),
                self.calendar_scheduling_task(),
                self.google_meet_creation_task()
            ],
            callback=self.email_router_agent()
        )

    @before_kickoff
    def identify(self, inputs):
        # announce manager and sub-agents
        crew_obj = self.crew()
        print(f"Assistant: Manager Agent -> {crew_obj.manager_agent.role}")
        print("Assistant: Crew Agents ->", [a.role for a in crew_obj.agents])
        return inputs

    @crew
    def crew(self) -> Crew:
        manager = self.email_router_agent()
        filtered_agents = [a for a in self.agents if a.role != manager.role]
        return Crew(
            agents=filtered_agents, # Exclude manager agent
            tasks=self.tasks, 
            process=Process.hierarchical,
            manager_agent=manager,
            verbose=True,
        )
